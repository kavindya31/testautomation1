package utils;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class PropertyFileReader {

    private Properties getData(String fileName) {

        Properties prop = new Properties();

        try (InputStream input = getClass().getClassLoader()
                .getResourceAsStream(fileName + ".properties")) {

            if (input == null) {
                throw new RuntimeException(fileName + ".properties file not found");
            }

            prop.load(input);

        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        return prop;
    }

    public String getProperty(String fileName, String key) {
        return getData(fileName).getProperty(key);
    }
}